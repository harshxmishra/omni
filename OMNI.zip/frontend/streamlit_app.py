import streamlit as st
import requests

API = "http://localhost:8000"

st.set_page_config(page_title="Omni Notetaker POC", layout="wide")

st.title("🧠 Omni Notetaker — POC")

st.markdown("Ingest knowledge → semantic search → AI answers")

tabs = st.tabs(["📥 Ingest", "🔎 Search", "🤖 Generate Answer"])

# with st.sidebar:
#     st.header("System Status")

#     try:
#         r = requests.get(f"{API}/health")
#         if r.status_code == 200:
#             st.success("Backend Connected")
#     except:
#         st.error("Backend Offline")

# -------------------------------------------------
# TAB 1 — INGEST
# -------------------------------------------------

with tabs[0]:

    st.header("Ingest Content")

    ingest_type = st.selectbox(
        "Choose ingestion type",
        ["web", "text"]
    )

    if ingest_type == "web":

        url = st.text_input("Enter webpage URL")

        if st.button("Ingest Webpage"):

            payload = {
                "type": "web",
                "payload": url
            }

            with st.spinner("Extracting and indexing..."):

                r = requests.post(f"{API}/ingest", json=payload)

            if r.status_code == 200:

                data = r.json()

                st.success("Webpage indexed!")

                st.json(data)

            else:

                st.error("Error ingesting webpage")

    if ingest_type == "text":

        text = st.text_area(
            "Paste text to ingest",
            height=200
        )

        if st.button("Ingest Text"):

            payload = {
                "type": "text",
                "payload": text
            }

            with st.spinner("Indexing text..."):

                r = requests.post(f"{API}/ingest", json=payload)

            if r.status_code == 200:

                st.success("Text indexed!") 

                st.json(r.json())

            else:

                st.error("Error ingesting text")

# -------------------------------------------------
# TAB 2 — SEARCH
# -------------------------------------------------

with tabs[1]:

    st.header("Semantic Search")

    query = st.text_input("Search query")

    topk = st.slider("Top results", 1, 10, 5)

    if st.button("Search Knowledge"):

        if query.strip() == "":
            st.warning("Enter a query first")

        else:

            with st.spinner("Searching knowledge base..."):

                r = requests.get(
                    f"{API}/search",
                    params={"q": query, "topk": topk}
                )

            if r.status_code == 200:

                results = r.json()

                if len(results) == 0:

                    st.warning("No results found")

                else:

                    for i, res in enumerate(results):

                        with st.expander(
                            f"Result {i+1} — Score {res['score']:.3f}"
                        ):

                            st.write("**Source:**", res["title"])
                            st.write(res["text"])

            else:

                st.error("Search failed")

# -------------------------------------------------
# TAB 3 — GENERATE ANSWER
# -------------------------------------------------

with tabs[2]:

    st.header("Generate AI Answer")

    question = st.text_input("Ask Omni a question")

    topk = st.slider("Context Chunks", 1, 10, 5, key="answer_topk")

    if st.button("Generate Answer"):

        if question.strip() == "":
            st.warning("Enter a question")

        else:

            with st.spinner("Omni is thinking..."):

                r = requests.post(
                    f"{API}/synthesize",
                    json={
                        "query": question,
                        "topk": topk
                    }
                )

            if r.status_code == 200:

                data = r.json()

                st.subheader("Answer")

                st.write(data["answer"])

                st.subheader("Sources")

                for s in data["sources"]:

                    with st.expander(s["title"]):

                        st.write(s["snippet"])

            else:

                st.error("Failed to generate answer")