import uuid
import trafilatura
import requests
from backend.app.indexer import embed, add_vectors
from backend.app.database import insert_chunk

CHUNK_SIZE = 300
OVERLAP = 50


def chunk_text(text):
    words = text.split()

    chunks = []
    start = 0

    while start < len(words):

        end = start + CHUNK_SIZE
        chunk = words[start:end]

        chunks.append(" ".join(chunk))

        start += CHUNK_SIZE - OVERLAP

    return chunks

def extract_webpage(url):

    downloaded = trafilatura.fetch_url(url)
    text = trafilatura.extract(downloaded)

    return text

def ingest_text(text, title="Untitled"):

    artifact_id = str(uuid.uuid4())

    chunks = chunk_text(text)

    vectors = embed(chunks)

    add_vectors(vectors)

    for i, chunk in enumerate(chunks):

        chunk_id = f"{artifact_id}_{i}"

        insert_chunk(
            chunk_id,
            artifact_id,
            chunk,
            title
        )

    return artifact_id


def ingest_web(url):

    text = extract_webpage(url)

    return ingest_text(text, title=url)