from backend.app.indexer import embed, search
import sqlite3
from pathlib import Path

DB_PATH = Path("storage/metadata.db")


def search_chunks(query, topk=5):

    qvec = embed([query])[0]

    indices, scores = search(qvec, topk)

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    results = []

    for idx, score in zip(indices, scores):

        row = cur.execute(
            "SELECT * FROM chunks LIMIT 1 OFFSET ?",
            (int(idx),)
        ).fetchone()

        if row:
            results.append({
                "chunk_id": row[0],
                "artifact_id": row[1],
                "text": row[2],
                "title": row[3],
                "score": float(score)
            })

    conn.close()

    return results