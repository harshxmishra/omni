from fastapi import FastAPI
from backend.app.ingestion import ingest_text, ingest_web
from backend.app.retrieval import search_chunks
from backend.app.database import init_db
from backend.app.synth import synthesize_answer

app = FastAPI()

init_db()


@app.get("/")
def root():
    return {"message": "Omni backend running"}


@app.post("/ingest")
def ingest(payload: dict):

    typ = payload["type"]
    data = payload["payload"]

    if typ == "text":
        artifact_id = ingest_text(data)

    elif typ == "web":
        artifact_id = ingest_web(data)

    else:
        return {"error": "unsupported type"}

    return {
        "artifact_id": artifact_id,
        "status": "indexed"
    }


@app.get("/search")
def search(q: str, topk: int = 5):

    results = search_chunks(q, topk)

    return results

@app.post("/synthesize")
def synth(body: dict):

    query = body["query"]
    topk = body.get("topk", 5)

    result = synthesize_answer(query, topk)

    return result