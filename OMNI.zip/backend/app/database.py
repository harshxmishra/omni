import sqlite3
from pathlib import Path

DB_PATH = Path("storage/metadata.db")

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS chunks(
        chunk_id TEXT PRIMARY KEY,
        artifact_id TEXT,
        text TEXT,
        title TEXT
    )
    """)

    conn.commit()
    conn.close()

def insert_chunk(chunk_id, artifact_id, text, title):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute(
        "INSERT INTO chunks VALUES (?, ?, ?, ?)",
        (chunk_id, artifact_id, text, title)
    )

    conn.commit()
    conn.close()    