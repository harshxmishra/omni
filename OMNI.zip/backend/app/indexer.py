import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
from pathlib import Path

INDEX_PATH = Path("storage/indexes/faiss.index")

model = SentenceTransformer("all-MiniLM-L6-v2")

dim = 384
index = faiss.IndexFlatL2(dim)

if INDEX_PATH.exists():
    index = faiss.read_index(str(INDEX_PATH))


def embed(texts):
    return model.encode(texts)


def add_vectors(vectors):
    arr = np.array(vectors).astype("float32")
    index.add(arr)
    faiss.write_index(index, str(INDEX_PATH))


def search(query_vector, k=5):
    q = np.array([query_vector]).astype("float32")
    distances, indices = index.search(q, k)
    return indices[0], distances[0]