import os
from openai import OpenAI
from backend.app.retrieval import search_chunks
from dotenv import load_dotenv

load_dotenv()

client =  OpenAI(
    api_key=os.environ.get("GROQ_API_KEY"),
    base_url="https://api.groq.com/openai/v1",
)


def build_prompt(query, chunks):

    context = ""    

    sources = []

    for i, c in enumerate(chunks):

        context += f"""
SOURCE {i+1}:
Title: {c['title']}
Text: {c['text']}

"""

        sources.append({
            "title": c["title"],
            "snippet": c["text"][:200]
        })

    prompt = f"""
You are an assistant answering questions using provided sources.

Sources:
{context}

Question:
{query}

Instructions:
- Answer concisely as less words possible.
- Use the sources to justify the answer.
- Cite sources like [1], [2].

Answer:
"""

    return prompt, sources


def synthesize_answer(query, topk=5):

    chunks = search_chunks(query, topk)

    if len(chunks) == 0:
        return {"answer": "No information found.", "sources": []}

    prompt, sources = build_prompt(query, chunks)

    response = client.chat.completions.create(
        model="openai/gpt-oss-20b",
        messages=[
            {"role": "user", "content": prompt}
        ],
        temperature=0.2
    )

    answer = response.choices[0].message.content

    return {
        "answer": answer,
        "sources": sources
    }