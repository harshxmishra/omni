#!/bin/bash

echo "Starting backend..."
uvicorn backend.app.main:app --reload --port 8000 &

echo "Starting frontend..."
streamlit run frontend/streamlit_app.py --server.port 8501